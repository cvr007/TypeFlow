# TypeFlow Windows app

This package wraps the latest TypeFlow HTML edition in an Electron desktop window.
The typing UI and game logic are kept in `index.html`.

## Build the Windows EXE on your Windows PC

1. Install **Node.js LTS** from https://nodejs.org/ (choose the Windows installer).
2. Extract this ZIP to a folder, for example `Desktop\\TypeFlow-Windows-App`.
3. Open that folder in File Explorer.
4. Click the address bar, type `cmd`, and press Enter.
5. Run these commands one at a time:

```bat
npm install
npm run build:win
```

6. Wait for the build to finish. Your portable Windows EXE will be inside the `dist` folder.

## Run it while developing

```bat
npm start
```

## Notes

- Build requires an internet connection the first time so npm can download Electron and its packaging tools.
- The EXE is built on your Windows PC; this ZIP is the source/build project, not the compiled EXE.
- Windows may show a SmartScreen warning because the app is unsigned. Only run a build you created yourself.
